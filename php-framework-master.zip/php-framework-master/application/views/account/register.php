<h3>Регистрация</h3>
<form action="/php-framework-master/account/login" method="post">
	<p>Логин</p>
	<p><input type="text"></p>
	<p>Пароль</p>
	<p><input type="text"></p>
	<b><button>Регистрация</button></b>
</form>