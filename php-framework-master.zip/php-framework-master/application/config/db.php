<?php

return [
	'host' => 'localhost',
	'name' => 'contacts_for_user',
	'user' => 'root',
	'password' => '',
];