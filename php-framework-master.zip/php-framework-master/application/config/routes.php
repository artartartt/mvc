<?php

return [

	'' => [
		'controller' => 'main',
		'action' => 'index',
	],
	'account/comment' => [
		'controller' => 'account',
		'action' => 'comment',
	],
	'account/login' => [
		'controller' => 'account',
		'action' => 'login',
	],

	'account/register' => [
		'controller' => 'account',
		'action' => 'register',
	],
	
];