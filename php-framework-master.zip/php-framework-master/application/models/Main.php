<?php

namespace application\models;

use application\core\Model;

class Main extends Model {

	public function getNews() {
		$result = $this->db->row("SELECT LEFT(text, 600) AS text,name,lastname,time,email FROM comments ORDER BY time desc limit 10;");
		return $result;
	}

}