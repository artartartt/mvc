<?php

namespace application\controllers;

use application\core\Controller;
use application\lib\Settings;
use application\models\Comment;


// stugem ardyoq ka aydpisi db te che ete ka avelacnem ete che sarqem avelacnem :(
//mnac login _registracia u mekel vor commenti va sexmem mecana u ira id/ov tvyalner@ sax cuyc ta ira

class AccountController extends Controller {


	public function loginAction() {
		$this->view->render('Вход');
	}

	public function registerAction() {
		$this->view->render('Регистрация');
	}
	public function commentAction() {

		$all_posts = [];
		$setings = new Settings();
		$all_posts = $setings->settings_comment($all_posts);

		if($all_posts['error'] == 'Stugvac'){
			$comment = new Comment();
			$comment->addComment($all_posts);
			header('Location: '.ROOT);
			exit;
		}
		if($all_posts == null)
			$this->view->render('Your Message');
		else{
			$this->view->render('Your Message',$all_posts);

		}

		
		

	}

}