<?php

namespace application\lib;
use application\models\Comment;

class Settings
{
	

    public function settings_comment($all_posts)
	{ 

		if(isset($_POST['Send_sms'])){
			
			$name = $_POST['name'];
			$lastname = $_POST['lastname'];
			$email = $_POST['email'];
			$text = $_POST['text'];
			
			$all_posts = [
				'name' => $name,
				'lastname' => $lastname,
				'email' => $email,
				'text' => $text,
				'error' => 'Stugvac'
			];

			if(strlen($name)<3){
				$all_posts['error'] = "Error name";
				return $all_posts;
			}
			if(strlen($lastname)<3){
				$all_posts['error'] = "Error lastname";
				return $all_posts;

			}
			if(strlen($email)<7){
				$all_posts['error'] = "Error email";
				return $all_posts;

			}
			if(strlen($text)<10){
				$all_posts['error'] = "Error text";
			}
			return $all_posts;

		}
	

	}
}

?>